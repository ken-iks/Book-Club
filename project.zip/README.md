To run project, type cd final-project into the terminal and press enter. Then type export API_KEY=pk_dd283de85b664e5f9a119cdcc250eed7 and press enter. Finally type flask run and press enter - then press the link that it will open up. At this point, a login screen will appear, as will the option to move to the registration page. When registering an account, ensure that the password contains both upper case lower case and a number, and is at least 8 characters. Also, ensure that the username is not already taken. 

Once an acccount has been made, you will be taken to the your user profile, which will now have 0 posts, 0 followers and 0 following. If you are looking for users to follow, some accounts have already been made, so you can go to the search page and find users like @JohnDoe, @JohnDoe2, @JohnDoe5 and a couple more. Edit profile section allows you to change you username or password, as well as delete a post (of course, you will need to have made a post before you can delete one). 

To make a post, you fill in the form in the profile page, which indicates name of book, name of author, review and rating. Once you press post, the post is automatically posted on your screen, and then the number of posts on your account increasrs by 1. 

The timeline page gives you a social-media esque timeline where the most recent post from all the accounts you follow comes first and it goes downwards reverse chronologically. 

If you want to unfollow a user that you follow, you just search up their username and then press unfollow. If you then re check your profile, they will no longer be in your following section, and their posts will no longer be on your timeline. 

Ensure that all forms are completley filled in before submitting in order for you not to recieve a Michael Jordan error message.

https://www.youtube.com/watch?v=mZ6lJKUYUCQ&ab_channel=KennyIkeji